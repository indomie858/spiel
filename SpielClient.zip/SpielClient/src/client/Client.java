package client;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Client {

    private MessageHistory receive;

    private String inputFromGUI = new String();

    private boolean connection;

    private Socket socket = null;

    public void run() {

        //Scanner message = new Scanner(System.in);
        receive = new MessageHistory();

        //socket = new Socket("localhost", 55555);
        //connection = true;
        //do {
        System.out.println("client trap");

        try {
            socket = new Socket("localhost", 55555);

            ArrayList<String> history;

            ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream()); // receives the arraylist object

            try {
                Object object = objectInputStream.readObject(); //reads the object

                history = (ArrayList<String>) object;    //this will store the list of messages from the server to the clients arraylist

                for (int i = 0; i < history.size(); i++) { //this will make sure to the store only the 10 most recent messages

                    receive.addMessage(history.get(i));     // addMessage method will get rid of old messages and store it into MessageHistory

                }

                for (int i = 0; i < receive.getMessageCount(); i++) {

                    System.out.println(receive.getMessage(i));

                }

            } catch (ClassNotFoundException ex) {

                System.out.println("error number 1");
                System.out.println(ex.toString());

            }

            //socket.close(); //closes the connection
        } catch (UnknownHostException e) {

            System.out.println("error number 2");
            System.out.println(e.toString());

        } catch (IOException e) {

            System.out.println("3. no host");

            System.out.println(e.toString());

            //break;
        }
        //} while (connection);
    }

    public void write() throws IOException {
        System.out.println("");

        OutputStream sendToServer = socket.getOutputStream(); // needed to send message

        OutputStreamWriter osw = new OutputStreamWriter(sendToServer);

        BufferedWriter bw = new BufferedWriter(osw);

        System.out.print("Enter message: ");

        //String m1 = message.nextLine();
        String m1 = inputFromGUI;

        if (m1.equalsIgnoreCase("goodbye fucktard")) {

            connection = false;

            socket.close();

            //break;
            //System.exit(0);
        } else {

            System.out.println("m1 has been entered");

            bw.write(m1);              //this will send the message

            System.out.println("m1 sent");

            bw.flush();

        }
    }

    public MessageHistory getReceive() {
        return receive;
    }

    public String getInputFromGUI() {
        return inputFromGUI;
    }

    public void setInputFromGUI(String inputFromGUI) {
        this.inputFromGUI = inputFromGUI;
    }

    public void closeSocket() throws IOException {
        socket.close();
    }

}
