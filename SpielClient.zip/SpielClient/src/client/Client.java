package client;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Client {

    private Socket socket;
    private boolean firstTime = true;
    private String username = null;
    private ClientThread clientThread;

    public static void main(String[] args) {
        new Client();
    }

    public Client() {
        try {
            socket = new Socket("localhost", 55555);
            clientThread = new ClientThread(socket, this);
            clientThread.start();

            //listenForInput();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public ClientThread getClientThread() {
        return clientThread;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void closeSocket() {
        clientThread.close();
    }




}
