/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spiel;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;

import client.Client;
import client.ClientThread;
import client.MessageHistory;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 *
 * @author gafaa
 */
public class ClientController implements Initializable {  //client controller
    
    private Client clientObj;
    private ClientThread clientThread;
    private boolean clientIsConnected = false;
    
    @FXML private TextArea chatBoxOutput = new TextArea();
    @FXML private TextField chatBoxInput = new TextField();
    @FXML private Button sendButton = new Button();
    
    @FXML
    private void handleSendButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        //label.setText("Hello World!");
    }
    
    @FXML
    private void handleConnectButtonAction(ActionEvent event) throws IOException {
        clientObj = new Client();
        sendButton.setDisable(false);
        clientIsConnected = true;
    }
    
    @FXML
    private void handleDisconnectButtonAction(ActionEvent event) throws IOException {
        clientIsConnected = false;
        clientObj.closeSocket();
    }
    
    @FXML
    private void handleChatDisplay(){
        
    }
    
    private boolean isNewMessage(){
        return true;
    }
    
    @FXML
    private void handleChatbox() throws IOException {
        String input = chatBoxInput.getText();
        clientThread = clientObj.getClientThread();
        String message = clientThread.getMessage();
        clientThread.sendStringToServer(input);
        chatBoxOutput.appendText(clientThread.getMessage() + "\n");
    }
    
    @FXML
    private void handleUsernameInputbox(){
        
    }
    
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        
        
    }    
    
}
