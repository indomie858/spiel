/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spiel;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;

import client.Client;
import client.MessageHistory;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javafx.scene.control.TextField;

/**
 *
 * @author gafaa
 */
public class FXMLDocumentController implements Initializable {
    
    private Client clientObj;
    
    @FXML private TextArea chatBoxOutput = new TextArea();
    @FXML private TextField chatBoxInput = new TextField();
    
    @FXML
    private void handleSendButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        //label.setText("Hello World!");
    }
    
    @FXML
    private void handleConnectButtonAction(ActionEvent event) throws IOException {
        
        clientObj = new Client();
        
        clientObj.run();
        
        
        
    }
    
    @FXML
    private void handleDisconnectButtonAction(ActionEvent event) throws IOException {
        
        clientObj.closeSocket();
    }
    
    @FXML
    private void handleChatboxInput(){
        
    }
    
    @FXML
    private void handleChatbox() throws IOException{
        
        MessageHistory messageHistoryObj = clientObj.getReceive();
        
        List<String> list = messageHistoryObj.getArrayObject();
        
        String input = chatBoxInput.getText();
        
        clientObj.setInputFromGUI(input);
        
        clientObj.write();
           
        
        //List<String> list = new ArrayList<String>();
        
        
        //list.add("bofa\n");
        //list.add("deez\n");
        //list.add("nutz\n");
        //list.add(clientObj.getInputFromGUI() + "\n");
        
        
        for (int i = 0; i < list.size(); i++){
            
            chatBoxOutput.appendText(list.get(i) + "\n");
            
        }
    }
    
    @FXML
    private void handleUsernameInputbox(){
        
    }
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        
        
    }    
    
}
