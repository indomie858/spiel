/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spiel;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;

import client.Client;
import client.ClientThread;
import client.Message;
import java.awt.Font;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.util.Duration;
import javafx.concurrent.*;
import javax.swing.JDialog;
import javax.swing.JOptionPane;

/**
 *
 * @author gafaa
 */
public class ClientController implements Initializable {  //client controller

    private Client clientObj;
    private ClientThread clientThread;
    private boolean clientIsConnected = false;

    private Message messageObj = new Message();

    @FXML
    private TextField usernameInputBox = new TextField();
    @FXML
    private TextArea chatBoxOutput = new TextArea();
    @FXML
    private TextField chatBoxInput = new TextField();
    @FXML
    private Button sendButton = new Button();
    @FXML
    private Button connectButton = new Button();

    @FXML
    private void handleSendButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        //label.setText("Hello World!");
    }

    @FXML
    private void handleConnectButtonAction(ActionEvent event) throws IOException {
        clientObj = new Client(this);
        clientThread = clientObj.getClientThread();
        clientThread.setguiController(this);
        sendButton.setDisable(false);
        connectButton.setDisable(true);
        String username = usernameInputBox.getText();

        if (username.length() == 0) {
            int randomNum = (int) (Math.random() * 100);
            clientThread.setUsername("No Name Bandit " + randomNum);
        } else if (username.length() > 10) {
            String subString = username.substring(0, 10);
            clientThread.setUsername(subString);
        } else {
            clientThread.setUsername(username);
        }
        clientIsConnected = true;

        messageObj.setMessage("BEGIN ");
        //clientThread.sendStringToServer("----------------------------------");
    }

    @FXML
    private void handleDisconnectButtonAction(ActionEvent event) throws IOException {
        clientIsConnected = false;
        clientObj.closeSocket();
    }
    
    @FXML
    private void helpButtonAction() {
        JOptionPane optionPane = new JOptionPane("How to use chatbox: \n"
                + "Step 1: Enter a username.    **Blank username will generate a random username. \n"
                + "Step 2: Enter a port number. **Port name must match with the other client you want to connect with. \n"
                + "Step 3: Enter an IP address. **Only enter an IP address if you are trying to connect with a different computer. \n"
                + "Step 4: Click connect.       **Assuming that the server is online; offline server will lead to no connection \n"
                + "Step 5: Type message.        **Enter any message you like to send \n"
                + "Step 6: Click send.          **Sends the message to the other client \n"
                + "\n"
                + "Button function: \n"
                + "Quit = closes the chat box \n"
                + "Connect = connects client to server \n"
                + "Disconnect = disconnect client from server \n"
                + "Send = send message to other client \n",
                JOptionPane.WARNING_MESSAGE);
        optionPane.setFont(new Font("Arial", Font.PLAIN, 36));
        JDialog dialog = optionPane.createDialog("Help");
        dialog.setAlwaysOnTop(true); // to show top of all other application
        dialog.setVisible(true); // to visible the dialog
    }
    
    @FXML
    private void quitButtonAction() {
        System.exit(0);
    }

    @FXML
    private void handleChatDisplay() {
        Platform.runLater(() -> {
            chatBoxOutput.appendText(clientThread.getMessage() + "\n");
        });
    }

    @FXML
    private void handleChatBox() throws IOException {
        String input = chatBoxInput.getText();
        String username = clientThread.getUsername();
        clientThread.sendStringToServer(username + ":" + input);
        String newMessage = clientThread.getMessage();
        messageObj.setMessage(newMessage);
        chatBoxInput.clear();
    }

    @FXML
    private void handleUsernameInputbox() {

    }

    public void updateChatBoxOutput(String text) {
        chatBoxOutput.appendText(text + "\n");

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

}
