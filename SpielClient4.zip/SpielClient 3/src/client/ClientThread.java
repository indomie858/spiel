//COMP 380 - Intro to Software Engineering
//Spiel Chat Application
//Programmers: Frank Serdenia, Jordan Bradshaw, Joseph Olympia, 
//             Hongsen Yang, Kenneth Woo, Gaven Grantz.

package client;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import spiel.ClientController;


/**
 *
 * @author gafaa
 */
public class ClientThread extends Thread {

    private Client clientObject;
    private Socket socketObject;
    private DataInputStream dataInputStream;
    private DataOutputStream dataOutputStream;
    private boolean isRunning = true;
    private boolean firstTime = true;
    private ArrayList<String> messages;
    private ObjectInputStream objectInputStream;
    private Object object;
    private String message = null;
    private String username;
    private MessageHistory storage = new MessageHistory();
    ClientController guiController = null;
    

    public ClientThread(Socket socket, Client client) {
        socketObject = socket;
        clientObject = client;
    }

    public void run() {

        try {
            if (firstTime){    //if this is clients first time connecting, take in arraylist from object input stream
                messages = new ArrayList<String>();
                objectInputStream = new ObjectInputStream(socketObject.getInputStream());
                try {
                    object = objectInputStream.readObject();
                    messages = (ArrayList<String>)object;
                
                } catch (ClassNotFoundException ex) {
                    ex.printStackTrace();
                }
                
                for (int i = 0; i < messages.size(); i++){
                    storage.addMessage(messages.get(i));
                }               
                
                for (int i = 0; i < storage.getMessageCount(); i++){  //this loop limits the messages to just 10
                    guiController.updateChatBoxOutput(storage.getMessage(i));
                    System.out.println(storage.getMessage(i));
                }
                    
                firstTime = false;   
            }
            dataInputStream = new DataInputStream(socketObject.getInputStream());
            dataOutputStream = new DataOutputStream(socketObject.getOutputStream());
            
            while (isRunning) {
                try {
                    while (dataInputStream.available() == 0) {
                        try {
                            Thread.sleep(1);
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        }
                    }
                    String tempString = dataInputStream.readUTF();
                    message = tempString;
                    messages.add(message);
                    guiController.updateChatBoxOutput(message);
                    
                    System.out.println(message);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }

            }
        } catch (IOException e) {
            isRunning = false;
        }
    }
    
    
    public void sendStringToServer(String message) {
        try {
            dataOutputStream.writeUTF(message);
            dataOutputStream.flush();
        } catch (IOException ex) {
            System.out.println("Client disconnected");
            close();
        }
    }
    
    public void close() {
        try {
            dataInputStream.close();
            dataOutputStream.close();
            socketObject.close();
        } catch (IOException ex) {
            //ex.printStackTrace();
        }
    }

    public String getMessage() {
        return message;
    }

    public Client getClientObject() {
        return clientObject;
    }

    public Socket getSocketObject() {
        return socketObject;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public ArrayList<String> getMessages() {
        return messages;
    }
    
    public void setguiController (ClientController tempguiController){
        guiController = tempguiController;
    }

}
