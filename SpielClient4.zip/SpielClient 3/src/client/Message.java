//COMP 380 - Intro to Software Engineering
//Spiel Chat Application
//Programmers: Frank Serdenia, Jordan Bradshaw, Joseph Olympia, 
//             Hongsen Yang, Kenneth Woo, Gaven Grantz.

package client;

/**
 *
 * @author gafaa
 */
public class Message {
    private String message;
    private boolean isNewMessage = false;

    
    public String getMessage(){
        isNewMessage = false;
        return message;
    }
    
    public void setMessage(String message){
        this.message = message;
        isNewMessage = true;
    }

    public boolean isNewMessage() {
        return isNewMessage;
    }
    
    
    
}
