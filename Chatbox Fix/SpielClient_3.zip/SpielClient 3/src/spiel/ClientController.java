/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spiel;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;

import client.Client;
import client.ClientThread;
import client.Message;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.util.Duration;
import javafx.concurrent.*;

/**
 *
 * @author gafaa
 */
public class ClientController implements Initializable {  //client controller

    private Client clientObj;
    private ClientThread clientThread;
    private boolean clientIsConnected = false;

    private Message messageObj = new Message();

    @FXML
    private TextField usernameInputBox = new TextField();
    @FXML
    private TextArea chatBoxOutput = new TextArea();
    @FXML
    private TextField chatBoxInput = new TextField();
    @FXML
    private Button sendButton = new Button();
    @FXML
    private Button connectButton = new Button();

    @FXML
    private void handleSendButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
        //label.setText("Hello World!");
    }

    @FXML
    private void handleConnectButtonAction(ActionEvent event) throws IOException {
        clientObj = new Client(this);
        clientThread = clientObj.getClientThread();
        clientThread.setguiController(this);
        sendButton.setDisable(false);
        connectButton.setDisable(true);
        String username = usernameInputBox.getText();

        if (username.length() == 0) {
            int randomNum = (int) (Math.random() * 100);
            clientThread.setUsername("&No Name Bandit " + randomNum);
        } else if (username.length() > 15) {
            String subString = username.substring(0, 15);
            clientThread.setUsername("&" + subString);
        } else {
            clientThread.setUsername("&" + username);
        }
        clientIsConnected = true;

        messageObj.setMessage("BEGIN ");
        //clientThread.sendStringToServer("----------------------------------");
    }

    @FXML
    private void handleDisconnectButtonAction(ActionEvent event) throws IOException {
        clientIsConnected = false;
        clientObj.closeSocket();
    }

    @FXML
    private void handleChatDisplay() {
        Platform.runLater(() -> {
            chatBoxOutput.appendText(clientThread.getMessage() + "\n");
        });
    }

    @FXML
    private void handleChatbox() throws IOException {
        String input = chatBoxInput.getText();
        String username = clientThread.getUsername();
        clientThread.sendStringToServer(username + ":" + input);
        String newMessage = clientThread.getMessage();
        messageObj.setMessage(newMessage);
        chatBoxInput.clear();
    }

    @FXML
    private void handleUsernameInputbox() {

    }

   public void updateChatBoxOutput(String text) {
            chatBoxOutput.appendText(text + "\n");
        
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }
    
}
