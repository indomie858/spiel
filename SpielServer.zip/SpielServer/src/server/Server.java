package server;

import java.net.*;
import java.util.*;
import java.io.*;
import java.sql.*;


public class Server {
    
    private final int port = 55555;  //to change port number
    
    private ServerSocket server = null;
    
    private Socket client = null;
    
    private MessageHistory history = new MessageHistory();
    
    private boolean connection;
   
    

    public void run() throws IOException{ // convert into a run method
        
        server = new ServerSocket(port);
        
        System.out.println("Local port: " + server.getLocalPort());
        
        System.out.println("Waiting for connection...");
        
        //Scanner message = new Scanner (System.in);
        
        //history.testing(); //automatically adds info to array for testing purposes; this is for testing purposes
        
        client = server.accept();
        
        
        //do {
            
            System.out.println("server trap");
            
            //client = server.accept(); //accepts connection
            
            System.out.println("Inetaddress: " + client.getInetAddress() + " Port: " + client.getPort());
            
            OutputStream outputStream = client.getOutputStream(); //use for writting something
            
            history.displayMessages();
            
            System.out.println("server check 1");
            
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
            
            objectOutputStream.writeObject(history.getArrayObject()); //sends the entire ArrayList to client
                     
            if (!client.isClosed()){
                
                connection = true;
                
                ///-----------code below should receive input-----------------//////////////////
                InputStream is = client.getInputStream();
            
                InputStreamReader isr = new InputStreamReader(is);
            
                BufferedReader br = new BufferedReader(isr);
            
                String reply = "Client: " + br.readLine();
            
                System.out.println("Client: " + reply);
            
                history.addMessage(reply);
                
                
                //////////////////////////////////////////////////////////////////
            } else {
                
                connection = false;
                
            }
            
            
                
            //closeServer();

        //} while (connection);
        
        
    }
    
    public void closeServer() throws IOException{
        
        server.close();
    }

    public ServerSocket getServer() {
        
        return server;
        
    }
    
    
}